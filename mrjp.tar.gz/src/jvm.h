#ifndef JVM_H
#define JVM_H

#include <vector>
#include <map>

std::vector<std::string> v, tmp;
std::map<std::string, std::string> m;
int stack_size = 1;
int locals_size = 0;

inline void multiply() {
    v.push_back("imul");
    --stack_size;
}

inline void add() {
    v.push_back("iadd");
    --stack_size;
}

inline void divide() {
    v.push_back("idiv");
    --stack_size;
}

inline void sub() {
    v.push_back("isub");
    --stack_size;
}

inline void integer(int i) {
    v.push_back("bipush " + std::to_string(i));
    ++stack_size;
}

inline void ident(std::vector<char> c) {
    std::string str(c.begin(), c.end());
    if (m.find(str) == m.end()) {
        return;
    }
    v.push_back("iload_" + m[str]);
    ++stack_size;
}

inline void ident_assignemt(std::vector<char> c) {
    std::string str(c.begin(), c.end());
    tmp.push_back(str);
}

inline void print() {
    v.push_back("invokevirtual java/io/PrintStream/println(I)V");
    v.push_back("getstatic  java/lang/System/out Ljava/io/PrintStream;");
}

inline void flush_assignment() {
    std::string str = tmp.back();
    if (m.find(str) == m.end()) {
        int index = m.size();
        m[str] = std::to_string(index);
    }
    v.push_back("istore_" + m[str]);
    tmp.clear();
    ++locals_size;
}

#endif
