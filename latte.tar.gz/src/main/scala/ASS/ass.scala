//TODO
// a = a.next a.next.elem

import sys.process._
import java.io._
import Etypes._
import Types._
import Stypes._
import Ptypes._
import scala.util.parsing.combinator.syntactical._
import scala.util.parsing.combinator._
import scala.collection.mutable._

import PParser.ProgramParser


object Assembly {

  var assCode : String = ""
  var currentType : Char = ' '
  var varCount : Int = -1
  var currentFunId : String = ""
  var currentStructId : String = ""
  var labelCount : Int = 0
  var stringCount : Int = 0
  var endLabelCount : Int = 0
  val varTypes = Map[String, String]()
  val structs = Map[String, Map[String, Int]]()
  val structTypes = Map[String, Map[String, String]]()
  val structFields = Map[String, List[Prog]]()
  val inheritance = Map[String, String]()
  val variables = Map[(LeftVar,Int), Int]()
  val varValues = Map[(LeftVar,Int), Int]()
  val strings = Map[String, Int]()
  val func = Map[String,(Type,List[PArg])]()

  def init(file : String) : Unit = {
    func.put("main", (TType("int"), List()))
    func.put("printInt", (TType("void"), List(PArg(TType("int"),Ident("a")))))
    func.put("printString", (TType("void"), List(PArg(TType("string"),Ident("a")))))
    func.put("readInt", (TType("int"), List()))
    func.put("readString", (TType("string"), List()))
    var map = Map[String,Int]()
    map.put("length", 0)
    structs.put("Array", map)
    assCode += ".file \"a\"\n.text\n.globl main\n"
    assCode += "strplace0\n"

    addString("%d\\\\n")
    addString("%s\\\\n")
    addString("%d")
    addString("%s%s")
    addString("%ms")
    assCode += "secretConcat:\n pushq	%rbp\n movq	%rsp, %rbp\n subq	$32, %rsp\n movq	%rdi, -24(%rbp)\n movq	%rsi, -32(%rbp)\n movq	$0, -8(%rbp)\n movq	-32(%rbp), %rcx\n movq	-24(%rbp), %rdx\n leaq	-8(%rbp), %rax\n movl	$.Str3, %esi\n movq	%rax, %rdi\n movl	$0, %eax\n call	asprintf\n movq	-8(%rbp), %rax\n leave\n ret\n"
  }

  def read(path : String) : String = {
    val lines = scala.io.Source.fromFile(path).mkString
    return lines
  }

  def program(input : PParser.ProgramParser.ParseResult[List[Prog]] ) : Unit = {
    input match {
      case PParser.ProgramParser.Success(tree, _) =>
        // println(tree)
        tree.map(read_fnDef)
        tree.map(progDef)
    }
  }

  def read_fnDef(input : Prog) = {
    input match {
      case PFnDef(typ, id, l, b) => 
        func.put(id, (typ, l))
      case PCDef(name, inherited, fields) => {
        var allFields = fields
        if (inherited != "") {
          allFields = structFields.get(inherited).get ++ allFields
        }
        structFields.put(name, allFields)
        structVars(name, allFields)
        currentStructId = name
        for (field <- allFields) {
          field match {
            case PFnDef(typ, id, l, b) => {
              addParams((List(PArg(TClass(name), Ident("self"))) ++ l.reverse), 1)
              currentFunId = id
              assCode += currentStructId + "_" + id +":\npushq %rbp\nmovq %rsp, %rbp\n"
              val blocks = countVarsBlock(b)
              if (blocks != 0) 
                assCode += "subq $" + 8*blocks + ", %rsp\n"
              block(b, 1)
              assCode += "_return_" + currentStructId + "_" + currentFunId + ":\n"
              assCode += "leave\n"
              assCode += "ret\n"
            }
            case _ =>
          }
        }
        currentStructId = ""
        currentFunId = ""
        removeBlock(0)
      }
    case _ =>
    }
  }

  def block(input : SBlock, blockNr : Int = 0) : Unit = {
    input match {
      case SBlock(stmtList) =>
        for(s <- stmtList)
          stmt(s, blockNr, labelCount)
    }
    removeBlock(blockNr)
  }

  def countVarsBlock(input : SBlock) : Int = {
    var variablesAmount = 0
    input match {
      case SBlock(stmtList) =>
        for(s <- stmtList)
          variablesAmount += countVars(s)
    }
    return variablesAmount
  }

  def countVars(input : Stmt) : Int = {
    input match {
      case SDecl(typ, itemList) =>
        return itemList.size
      case SCond(_, s) =>
        return countVars(s)
      case SCondElse(_, s1, s2) =>
        return math.max(countVars(s1), countVars(s2))
      case SWhile(_, s) =>
        return countVars(s)
      case SFor(_, _, _, s) =>
        return countVars(s) + 2
      case SBlock(s) =>
        return countVarsBlock(SBlock(s))
      case _ =>
        return 0
      }
  }

  def addParams(params : List[PArg], blockNr : Int) = {
    varCount = 2
    for (param <- params) 
      param match {
        case PArg(TArray(typ), id) => {
          putVariable(id, blockNr, TArray(typ))
          varCount += 1
          varTypes.put(id.getName(), "Array")
        }
        case PArg(TClass(typ), id) => {
          varTypes.put(id.getName(), typ)
          putVariable(id, blockNr, TType(typ))
          varCount += 1
        }
        case PArg(typ, id) => {
          putVariable(id, blockNr, typ)
          varCount += 1
        }
      }
      varCount = -1
  }

  def progDef(input : Prog) = {
    varCount = 2
    input match {
      case PFnDef(typ, id, l, b) => 
        addParams(l.reverse, 0)
        currentFunId = id
        assCode += id +":\npushq %rbp\nmovq %rsp, %rbp\n"
        val blocks = countVarsBlock(b)
        if (blocks != 0) 
          assCode += "subq $" + 8*blocks + ", %rsp\n"
        block(b)
        assCode += "_return_" + currentFunId + ":\n"
        // assCode += "addq $" + 4*countVarsBlock(b) + ", %rsp\n"
        assCode += "leave\n"
        assCode += "ret\n"
      case _ =>
    }
  }

  def structVars(name : String, fields : List[Prog]) : Unit = {
    varCount = 0
    var vars = Map[String, Int]()
    var types = Map[String, String]()
    for (field <- fields) {
      field match {
        case PDecl(typ, items) => {
          for (item <- items) {
            Checker.variables.put((Ident(item.getName()), 0), typ)
            vars.put(item.getName(), varCount)
            types.put(item.getName(), typ.getName())
            if (typ.isInstanceOf[TClass]) varTypes.put(item.getName(), typ.getName())
            varCount += 1
          }
        }
        case _ =>
      }
    }
    // println("struct put", name)
    structs.put(name, vars)
    structTypes.put(name, types)
  }

  def item(input : Item, blockNr : Int, labelNr : Int) = {
    input match {
      case IInit(id, e) => stmt(SAss(id, e), blockNr, labelNr)
      case INewInit(id, r) => {
        stmt(SNewAss(id, r), blockNr, labelNr)
      }
      case INoInit(id) => stmt(SAss(id, EConst(0)), blockNr, labelNr)
    }
  }

  def createArray(id : LeftVar, blockNr : Int, e : Expr, typ : String = "Array") = {
    val adrress = getAdrress(id, blockNr)
    // varCount -= 1
    expr(e, blockNr)
    assCode += "movq %rax, %rbx\n"
    assCode += "incq %rax\n"
    callMalloc()
    assCode += "movq %rax, " + adrress + "(%rbp)\n"
    if (typ == "Array") assCode += "movq %rbx, (%rax)\n"
    varTypes.put(id.getName(), typ)
  }

  def callMalloc() = {
    assCode += "imulq $8, %rax\n"
    assCode += "movq %rax, %rdi\n"
    assCode += "call malloc\n"
  }

  def putArray(id : LeftVar) = {
    var map = Map[String,Int]()
    if (structs.contains(id.getName())) {
      map = structs.get(id.getName()).get
    }
    map.put("length", -1)
    structs.put(id.getName(), map)
  }

/*  def initVar(id : LeftVar, blockNr : Int, typ : Type, e : Expr) = {
    expr(e,blockNr)
    putVariable(id, blockNr, typ)
    assCode += "movq %rax, " + 4*varCount + "(%rbp)\n"
    varCount -= 1
  } */

  def removeBlock(blockNr : Int) = {
    for (((k,b),_) <- variables) {
      if (b == blockNr) variables.remove((k,b))
    }    
    for (((k,b),_) <- Checker.variables) {
      if (b == blockNr) Checker.variables.remove((k,b))
    }    
  }

  def stmt(input : Stmt, blockNr : Int, labelNr : Int) : Unit = {
    var adrress=0
    input match {
      case SDecl(TArray(typ),itemList) => 
        for(id <- itemList) {
          putVariable(id.getVar(), blockNr, TArray(typ))
          varTypes.put(id.getName(), "Array")
          varCount -= 1
          item(id, blockNr, labelNr)
        }
      case SDecl(TClass(typ),itemList) => 
        for(id <- itemList) {
          putVariable(id.getVar(), blockNr, TType(typ))
          varTypes.put(id.getName(), typ)
          varCount -= 1
          item(id, blockNr, labelNr)
        }
      case SDecl(typ,itemList) => 
        for(id <- itemList) {
          putVariable(id.getVar(), blockNr, typ)
          varCount -= 1
          item(id, blockNr, labelNr)
        }
      case SDecr(id) => stmt(SAss(id, ESub(id, EConst(1))), blockNr, labelNr)
      case SInc(id) => stmt(SAss(id, EAdd(id, EConst(1))), blockNr, labelNr)
      case SExpr(e) => expr(e,blockNr)
     case SAss(Table(id, index), e) => {
        expr(index,blockNr); 
        adrress = getAdrress(Ident(id), blockNr)
        assCode += "leaq 8(,%rax,8), %rcx\n"
        assCode += "movq " + adrress + "(%rbp), %rax\n"
        assCode += "addq %rax, %rcx\n" 
        expr(e,blockNr); 
        assCode += "movq %rax, (%rcx)\n" 
      }
      case SAss(LeftItem(l), e) => {
        adrress = getAdrress(l.head, blockNr)
        assCode += "movq $" + getStructField(l, blockNr).toString + ", %rax\n"
        assCode += "leaq 0(,%rax,8), %rcx\n"
        assCode += "movq " + adrress + "(%rbp), %rax\n"
        assCode += "addq %rax, %rcx\n" 
        expr(e,blockNr); 
        assCode += "movq %rax, (%rcx)\n" 
      }
      case SAss(s, e) => {
        expr(e,blockNr); 
        addVarValue(s, e, blockNr)
        adrress = getAdrress(s, blockNr)
        if (adrress != -1) {
          assCode += "movq %rax, " + adrress + "(%rbp)\n"
        }
        else {
          val index = getStructField(List(Ident(currentStructId), s), blockNr, true)
          assCode += "movq 16(%rbp), %rbx\n"
          assCode += "movq %rax, " + (index*8) + "(%rbx)\n"
        }
      }
      /*
      case SAss(Struct(id, field), e) => {
        val index = expandStruct(id, field, blockNr)
        stmt(SAss(Table(id, EConst(index._1)), e), blockNr, labelNr)
      } */
      case SNewAss(id, RTable(t, e)) => {
        createArray(id, blockNr, e)
      }
      case SNewAss(id, RStruct(s)) => {
        val size = getStructSize(id.getName())
        createArray(id, blockNr, EConst(size), s)
      }
      case SVRet() => {
        if (currentStructId != "")
          assCode += "jmp _return_" + currentStructId + "_" + currentFunId + "\n"
        else
          assCode += "jmp _return_" + currentFunId + "\n"
      }
      case SRet(e) => {
        expr(e,blockNr)
        if (currentStructId != "")
          assCode += "jmp _return_" + currentStructId + "_" + currentFunId + "\n"
        else
          assCode += "jmp _return_" + currentFunId + "\n"
      }
      case SCond(e,s) => 
        expr(e,blockNr)
        assCode += "cmpq $0, %rax\n"
        assCode += "je .endIf" + labelNr + "\n"
        stmt(s, blockNr, labelNr+1)
        assCode += ".endIf" + labelNr + ":\n"

      case SCondElse(e,s1, s2) => 
        expr(e,blockNr)
        assCode += "cmpq $0, %rax\n"
        assCode += "je .else" + labelNr + "\n"
        stmt(s1, blockNr, labelNr+2)
        assCode += "jmp .endElse" + (labelNr + 1) + "\n"
        assCode += ".else" + labelNr + ":\n"
        stmt(s2, blockNr, labelNr+2)
        //TODO po co to?
        assCode += ".endElse" + (labelNr + 1) + ":\n"

      case SWhile(e, s) =>
        assCode += "while_" + labelNr + ":\n"
        expr(e,blockNr)
        assCode += "cmpq $0, %rax\n"
        assCode += "je end" + labelNr + "\n"
        stmt(s, blockNr, labelNr+2)
        assCode += "jmp while_" + labelNr + "\n"
        assCode += "end" + labelNr + ":\n"
      case SFor(t, i1, i2, s) => {
        labelCount += 1
        putVariable(Ident("mysecretindex"), blockNr, t)
        varCount -= 1
        putVariable(Ident(i1), blockNr, t)
        varCount -= 1
        val indexAdrress = getAdrress(Ident("mysecretindex"), blockNr)
        val adrress = getAdrress(Ident(i1), blockNr)
        val arrayAdrress = getAdrress(Ident(i2), blockNr)
        assCode += "movq $0, " + indexAdrress + "(%rbp)\n"
        assCode += "for" + labelNr + ":\n"
        assCode += "movq " + arrayAdrress + "(%rbp), %rax\n"
        assCode += "movq (%rax), %rax\n"
        assCode += "cmpq %rax, " + indexAdrress + "(%rbp)\n"
        assCode += "movq " + indexAdrress + "(%rbp), %rax\n"
        assCode += "jge end" + labelNr + "\n"
        assCode += "leaq 8(,%rax,8), %rdx\n"
        assCode += "movq " + arrayAdrress + "(%rbp), %rax\n"
        assCode += "addq %rdx, %rax\n"
        assCode += "movq (%rax), %rax\n"
        assCode += "movq %rax, " + adrress + "(%rbp)\n"
        stmt(s, blockNr, labelNr+1)
        assCode += "addq $1, " + indexAdrress + "(%rbp)\n"
        assCode += "jmp for" + labelNr + "\n"
        assCode += "end" + labelNr + ":\n"
      }
        
      case SBlock(x) =>
        labelCount = math.max(labelCount, labelNr)
        block(SBlock(x), blockNr + 1)
      // TODO
      case _ => 
    }
  }

  def basicOperation(e1 : Expr, e2 : Expr, blockNr : Int) : Unit = {
    expr(e1,blockNr)
    assCode += "pushq %rax\n"
    expr(e2,blockNr)
    assCode += "popq %rbx\n"
  }
  def compareOperation(text : String, e1 : Expr, e2 : Expr, blockNr : Int) : Unit = {
    basicOperation(e1, e2, blockNr)
    assCode += "cmpq %rax, %rbx\n"
    assCode += "movq $1, %rax\n"
    assCode += text + " T"+labelCount+"\n"
    assCode += "movq $0, %rax\n"
    assCode += "T"+labelCount+":\n"
    labelCount += 1
  }

  def expandStruct(id : String, field : LeftVar, blockNr : Int) : (Int, String) = {
    var typ = ""
    if (varTypes.contains(id)) {
      typ = varTypes.get(id).get
    }
    else {
      typ = id
    }
    //TODO more dots
    val index = structs.get(typ).get.get(field.getName()).get
 //   expr(Table(id, EConst(index)), blockNr)
    val newId = structTypes.get(typ).get.get(field.getName()).get
    field match {
  //    case Struct(_, f) => expandStruct(newId, f, blockNr)
      //TODO APP can return reference to struct
    //  case StructApp(s, EApp(i, l) => expr(EApp(Struct //sxpandStruct(newId, f, blockNr)
//      case Table(i, e) => expr(Table(i, EConst(index)), blockNr);
      case _ =>
    }
    return (index,"")

  }

  def getAdrress(idd : LeftVar, blockNr : Int) : Int = {
    val id = Ident(idd.getName())
    if (variables.contains((id, blockNr))) {
      return variables.get((id, blockNr)).get*8
    }
    if (blockNr < 0) return -1;
    return getAdrress(id, blockNr - 1)
  }


  def getStructField(leftItem : List[LeftVar], blockNr : Int, static: Boolean = false) : Int = {
    //TODO more dots
    var typ = ""
    if (static)
      typ = leftItem.head.getName()
    else 
      typ = varTypes.get(leftItem.head.getName()).get
    return structs.get(typ).get.get(leftItem(1).getName()).get
  }

  def getStructSize(id : String) : Int = {
    val name = varTypes.get(id).get
    return structs.get(name).get.size
  }

  def addString(id : String) : Unit = {
    val newString = ".Str"+stringCount+":\n.string \""+id+"\"\nstrplace"+(stringCount+1)
    assCode = assCode.replaceFirst("strplace"+stringCount, newString)
    strings.put(id, stringCount)
    stringCount += 1
  }

  def evaluateExpr(input : Expr, blockNr : Int) : Int = {
    input match {
      case ELitTrue() => return 1
      case ELitFalse() => return 0
      case Ident(s) => return getVarValue(Ident(s), blockNr)
      case EConst(v) => return v
      case LeftItem(l) => return 0
      case EAdd(e1, e2) =>
        return evaluateExpr(e1, blockNr) + evaluateExpr(e2, blockNr)
      case ESub(e1, e2) =>
        return evaluateExpr(e1, blockNr) - evaluateExpr(e2, blockNr)
      case EMul(e1, e2) =>
        return evaluateExpr(e1, blockNr) * evaluateExpr(e2, blockNr)
      case EDiv(e1, e2) =>
        return evaluateExpr(e1, blockNr) / evaluateExpr(e2, blockNr)
      case EMod(e1, e2) =>
        return evaluateExpr(e1, blockNr) % evaluateExpr(e2, blockNr)
      case EUMinus(e) => return -evaluateExpr(e, blockNr)
      case _ => return -1
    }
  }
        
  def expr(input : Expr, blockNr : Int) : Unit = {
    input match {
      case ELitTrue() => assCode += "movq $1, %rax\n"
      case ELitFalse() => assCode += "movq $0, %rax\n"
      case Ident(s) => {
        val adrress = getAdrress(Ident(s), blockNr)
        //TODO correct to check if currentStructId = ""
        if (adrress != -1) {
          assCode += "movq " + adrress + "(%rbp), %rax\n"
        }
        else {
          val index = getStructField(List(Ident(currentStructId), Ident(s)), blockNr, true)
          assCode += "movq 16(%rbp), %rax\n"
          assCode += "movq " + (index*8) + "(%rax), %rax\n"
        }
      }
      case Table(s, e) => {
        val adrress = getAdrress(Ident(s), blockNr)
        expr(e,blockNr); 
        assCode += "leaq 8(,%rax,8), %rdx\n"
        assCode += "movq " + adrress + "(%rbp), %rax\n"
        assCode += "addq %rdx, %rax\n" 
        assCode += "movq (%rax), %rax\n" 
    }
      case LeftItem(l) => {
        if (Checker.getType(l.head, blockNr).isInstanceOf[TArray]) {
        }

        val adrress = getAdrress(l.head, blockNr)
        assCode += "movq $" + getStructField(l, blockNr) +", %rax\n"
        assCode += "leaq 0(,%rax,8), %rdx\n"
        assCode += "movq " + adrress + "(%rbp), %rax\n"
        assCode += "addq %rdx, %rax\n" 
        assCode += "movq (%rax), %rax\n" 
      }
      case RTable(_, e) => {
        expr(e, blockNr)
      }
      case RStruct(s) => {
        val size = getStructSize(s)
      }
      case EConst(v) => assCode += "movq $" + v + ", %rax\n"
      case EString(s) => {
        if (!strings.contains(s)) {
          addString(s)
        }
        assCode += "movq $(.Str" + strings.get(s).get + "), %rax\n"
      }
      case EApp(i, l) => 
        if (i == "printInt") {
          expr(l.head, blockNr)
          assCode += "movq %rax, %rsi\nmovq $.Str0, %rdi\nmovq $0, %rax\ncall printf\n"
        }
        else if (i == "printString") {
          expr(l.head, blockNr)
          assCode += "movq %rax, %rsi\nmovq $.Str1, %rdi\nmovq $0, %rax\ncall printf\n"
        }
        else if (i == "readInt") {
          assCode += "pushq $0\n movq %rsp, %rsi\nmovq $.Str2, %rdi\ncall scanf\npopq %rax\n"
        }
        else if (i == "readString") {
          assCode += "pushq $0\n movq %rsp, %rsi\nmovq $.Str4, %rdi\ncall scanf\npopq %rax\n"
        }
        else {
          for (e <- l) { 
            expr(e,blockNr);
            assCode += "pushq %rax\n";
          }
          assCode += "call " + i + "\n"
          for (_ <- l) { assCode += "popq %rbx\n"; }
        }
        // for (e <- l) { assCode += "popq %rbx\n"; }
//        assCode += getMethodName(i)
      case EClassApp(s, EApp(i, l)) => {
        val address = getAdrress(Ident(s), blockNr)
        for (e <- l) { 
          expr(e,blockNr);
          assCode += "pushq %rax\n";
        }
        assCode += "movq " + address + "(%rbp), %rax\n"
        assCode += "pushq %rax\n";
        assCode += "call " + varTypes.get(s).get + "_" + i + "\n"
        assCode += "popq %rbx\n"
        for (_ <- l) { assCode += "popq %rbx\n"; }
      }

      case EAdd(e1, e2) =>
        basicOperation(e1, e2, blockNr)
        
        if (Checker.getType(e1, blockNr) == TType("string")) {
          assCode += "movq %rax, %rsi\nmovq %rbx, %rdi\ncall secretConcat\n"
        }
        else {
          assCode += "addq %rbx, %rax\n"
        }

      case ESub(e1, e2) =>
        basicOperation(e2, e1, blockNr)
        assCode += "subq %rbx, %rax\n"
      case EMul(e1, e2) =>
        basicOperation(e1, e2, blockNr)
        assCode += "imulq %rbx\n"
      case EDiv(e1, e2) =>
        basicOperation(e2,e1,blockNr)
        assCode += "movq $0, %rdx\n"
        assCode += "idivq %rbx\n"
      case EMod(e1, e2) =>
        basicOperation(e2,e1,blockNr)
        assCode += "movq $0, %rdx\n"
        assCode += "idivq %rbx\n"
        assCode += "mov %rdx, %rax\n"
      case EUMinus(e) => expr(e, blockNr); assCode += "negq %rax\n"
      case EUNeg(e) => {
        expr(e, blockNr)
        assCode += "cmpq $0, %rax\n"
        assCode += "sete %al\n"
        assCode += "movzbq %al, %rax\n"
      }
      case ECast(_) => {
        assCode += "movq $0, %rax\n"
      }
      case EGt(e1, e2) =>
        //ifeq label
        compareOperation("jg", e1, e2, blockNr)
      case ELt(e1, e2) =>
        compareOperation("jl", e1, e2, blockNr)
      case EGeq(e1, e2) =>
        compareOperation("jge", e1, e2, blockNr)
      case ELeq(e1, e2) =>
        compareOperation("jle", e1, e2, blockNr)
      case EEq(e1, e2) =>
        compareOperation("je", e1, e2, blockNr)
      case ENeq(e1, e2) =>
        compareOperation("jne", e1, e2, blockNr)
      case EAnd(e1, e2) =>
        expr(e1,blockNr); 
        assCode += "cmpq $0, %rax\n"
        assCode += "je false" + endLabelCount + "\n"
        expr(e2,blockNr)
        assCode += "cmpq $0, %rax\n"
        assCode += "je false" + endLabelCount + "\n"
        assCode += "movq $1, %rax\n"
        assCode += "jmp true" + endLabelCount + "\n"
        assCode += "false" + endLabelCount + ":\n"
        assCode += "movq $0, %rax\n"
        assCode += "true" + endLabelCount + ":\n"
        endLabelCount += 1
      case EOr(e1, e2) =>
        expr(e1,blockNr); 
        assCode += "cmpq $1, %rax\n"
        assCode += "je true" + endLabelCount + "\n"
        expr(e2,blockNr)
        assCode += "cmpq $1, %rax\n"
        assCode += "je true" + endLabelCount + "\n"
        assCode += "movq $0, %rax\n"
        assCode += "jmp false" + endLabelCount + "\n"
        assCode += "true" + endLabelCount + ":\n"
        assCode += "movq $1, %rax\n"
        assCode += "false" + endLabelCount + ":\n"
        endLabelCount += 1
      }
  }

  def putVariable(idd : LeftVar, blockNr : Int, typ : Type) = {
    var id : LeftVar = Ident("")
    idd match {
      case LeftItem(l) =>
        id = l.head
      case _ =>
        id = Ident(idd.getName())
    }
    variables.put((id, blockNr), varCount)
    Checker.variables.put((id, blockNr), typ)
    var i = 1;
    while (variables.contains((id, blockNr+i))) {
      variables.remove(id, blockNr+i)
      i = i+1;
    }
    i = 1;
    while (Checker.variables.contains((id, blockNr+i))) {
      Checker.variables.remove(id, blockNr+i)
      i = i+1;
    }
    copyValue(idd, blockNr)
  }

  def addVarValue(idd : LeftVar, expr : Expr, blockNr : Int) = {
    varValues.put((idd, blockNr), evaluateExpr(expr, blockNr))
  }

  def getVarValue(idd : LeftVar, blockNr : Int) : Int = {
    val id = Ident(idd.getName())
    if (varValues.contains((id, blockNr))) {
      return varValues.get((id, blockNr)).get
    }
    if (blockNr < 0) return -1;
    return getVarValue(id, blockNr - 1)
  }

  def copyValue(idd : LeftVar, blockNr : Int) = {
    var i : Int = blockNr - 1
    var l : Option[Int] = None
    while (i >= 0) {
      l = variables.get((idd, i))
      if (!l.isEmpty) {
        val oldAdrress : Int = l.get*8
        val newAdrress : Int = variables.get((idd, blockNr)).get*8
        assCode += "movq " + oldAdrress + "(%rbp), %rax\n"
        assCode += "movq %rax, " + newAdrress + "(%rbp)\n"
      }
      i = i - 1
    }
  }
    
  def finish() = {
    assCode = assCode.replaceFirst("strplace"+stringCount+"\n","")
  }

  def printToFile(f: java.io.File)(op: java.io.PrintWriter => Unit) {
    val p = new java.io.PrintWriter(f)
    try { op(p) } finally { p.close() }
  }

  def removeComments(code : String) : String = {
    return code.replaceAll("//.*\n", "\n").replaceAll("#.*\n", "\n").replaceAll("/\\*[\n|\\w\\W]*?\\*/", "\n")
  }

  def main(args:Array[String]) = {
    if (args.length == 0) {
      println("No latte file provided")
      System.exit(0)
    }
    val code = removeComments(read(args(0)))
    // println(code)
    try {
      val tokens = ProgramParser.parse(code)
      ProgramParser.test(code)
      Checker.check(tokens)
      val dir_name = (args(0).substring(0, args(0).lastIndexOf("/")+1))
      val file_name = ((args(0).substring(args(0).lastIndexOf("/")+1)))
      val index = file_name.indexOf(".")
      if (index != -1) {
        var pref_name = file_name.substring(0,file_name.indexOf("."))
        init(pref_name)
        pref_name = dir_name + pref_name
        program(tokens)
        finish()
        val p = new java.io.PrintWriter(new File(pref_name + ".s"))
        for (line <- assCode.split('\n')) {
          if (line.last != ':')
            p.print('\t')
            p.println(line)
        }
        p.close()
        "gcc -c " + pref_name + ".s -o" + pref_name + ".o" !;
        "gcc -o " + pref_name + " " + pref_name + ".o" !;;
        System.err.println("OK\n")
      } 
    } catch {
      case _ : Throwable => System.exit(0)
    }
  }
}
