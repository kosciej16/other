import java.io._
import Etypes._
import Types._
import Stypes._
import Ptypes._
import scala.util.parsing.combinator.syntactical._
import scala.util.parsing.combinator._
import scala.collection.mutable._

import PParser.ProgramParser


object Checker {

  var assCode : String = ""
  var currentType : Char = ' '
  var varCount : Int = 1
  var pushCount : Int = 1
  var currentFunId : String = ""
  var currentFunType : Type = TType("")
  var labelCount : Int = 0
  var stringCount : Int = 0
  var endLabelCount : Int = 0
  var variables = Map[(LeftVar,Int), Type]()
  var classes = Map[Type, Map[String, Type]]()
  var arrays = Map[(String, Int), (Type, Int)]()
  val strings = Map[String, Int]()
  val func = Map[String,(Type,List[PArg])]()

  def init() : Unit = {
    func.put("printInt", (TType("void"), List(PArg(TType("int"),Ident("a")))))
    func.put("printString", (TType("void"), List(PArg(TType("string"),Ident("a")))))
    func.put("readString", (TType("string"), List()))
    func.put("readInt", (TType("int"), List()))
    classes.put(TArray(TType("")), Map("length" -> TType("int")))
  }

  def read(path : String) : String = {
    val lines = scala.io.Source.fromFile(path).mkString
    return lines
  }

  def exit(msg : String) = {
      System.err.println("ERROR\n")
      System.err.println(msg)
      System.exit(0)
  }


  def program(input : PParser.ProgramParser.ParseResult[List[Prog]] ) : Unit = {
    input match {
      case PParser.ProgramParser.Success(tree, _) =>
        // println(tree)
        tree.map(read_fnDef)
        tree.map(fnDef)
      case e =>
    }
  }

  def read_fnDef(input : Prog) = {
    input match {
      case PFnDef(typ, id, l, b) => 
        func.put(id, (typ, l))
      case _ =>
      }
  }

  def block(input : SBlock, blockNr : Int = 0) : Unit = {
    input match {
      case SBlock(stmtList) =>
        for(s <- stmtList) {
          stmt(s, blockNr)
        }
    }
  }

  def returnTypeBlock(input : SBlock, blockNr: Int = 0) : Boolean = {
    var returned : Boolean = false
    input match {
      case SBlock(stmtList) => {
        for(s <- stmtList) {
          returned = checkReturnType(s, blockNr)
        }
      }
    }
    return returned
  }

  def checkReturnType(input : Stmt, blockNr : Int) : Boolean = {
    input match {
      case SRet(e) => {
        var typ = getType(e, blockNr)
        if (typ != currentFunType && typ != TType("any"))
          exit("Function " + currentFunId + " should return " + currentFunType.getType())
        else
          return true
      }
      case SVRet() => {
        if (currentFunType != TType("void"))
          exit("Function " + currentFunId + " should return void instead of " + currentFunType)
      }
      case SCond(ELitTrue(),s) => {
        checkReturnType(s, blockNr)
        return true
      }
      case SCondElse(ELitTrue(),s, _) => {
        return checkReturnType(s, blockNr)
        return true
      }
      case SCondElse(ELitFalse(),_, s) => {
        checkReturnType(s, blockNr)
        return true
      }
      case SCondElse(e,s1, s2) => {
        checkReturnType(s1, blockNr)
        checkReturnType(s2, blockNr)
        return true
      }
      case SBlock(b) => return returnTypeBlock(SBlock(b), blockNr)
      case _ =>
    }
    return false
  }


  def varExists(id : LeftVar, blockNr : Int) = {
    if (variables.contains((id, blockNr))) {
      exit("in function " + currentFunId + " variable " + id.getName() + " exists")
    }
  }

  def goodType(id : LeftVar, blockNr : Int, typ : Type) : Type = {
    // println(variables)
    // println(id)
    // println(blockNr)
    id match {
      case Table(s, e) =>
        return TArray(TType("any"))
      case LeftItem(l) =>
        return TType("any")
        // return classType(l, blockNr)
      case _ =>
    }
    if (blockNr < 0) {
      exit("in function " + currentFunId + " no variable " + id.getName())
    }
    if (!variables.contains((id, blockNr))) {
      return goodType(id, blockNr - 1, typ)
    }
    else if (typ.getType() != "any" && variables.get(id, blockNr).get != typ) {
      exit("in function " + currentFunId + " " + id.getName() + " has bad type")
    }
    return variables.get(id,blockNr).get
  }

  def expTypeList(input : Expr, blockNr : Int, types : List[Type]) {
    val typ : Type = getType(input, blockNr)
    if (!types.contains(typ)) {
      exit("bad expr type")
    }
  }
  def expType(input : Expr, blockNr : Int, typ : Type = TType("int"), expType : Type = TType("int")) : Type = {
    // println("EXP TYPE " + input + "   " + typ)
    if (typ == TType("any") || typ == TArray(TType("any"))) {
      return typ
    }
    // println(input)
    var t = getType(input, blockNr)
    if (t != TType("any") && (t != typ || typ != expType)) {
      exit("in function " + currentFunId + " expression " + input + " should have type " + typ.getType())
    }
    return typ
  }

  def classType(input : List[LeftVar], blockNr : Int) : Type = {
    // println("class type " + input)
    var clType : Type = goodType(input.head, blockNr, TType("any"))
    // println("classes " + classes)
    for (l <- input.tail) {
      // println(clType)
      if (clType.isInstanceOf[TArray]) {
        clType = classes.get(TArray(TType(""))).get(l.getName())
      }
      else if (clType.isInstanceOf[TClass]) {
        clType = classes.get(clType).get(l.getName())
      }
    }
    return clType
  }

  def addVar(idd : LeftVar, typ : Type, blockNr : Int) = {
    var id : LeftVar = Ident("")
    idd match {
      case LeftItem(l) =>
        id = l.head
      case Table(t, e) =>
        // arrays.put((s, blockNr), (typ
        id = Ident(idd.getName())
      case _ =>
        id = Ident(idd.getName())
    }
    varExists(id, blockNr)
    variables.put((id, blockNr), typ)
  }

  def removeBlock(blockNr : Int) = {
    for (((k,b),v) <- variables) {
      if (b == blockNr) variables.remove((k,b))
    }    
  }

  def fnDef(input : Prog) = {
    val blockNr = 0
    input match {
      case PFnDef(typ, id, l, b) => 
        // println("ASSASA " + id)
        currentFunType = typ
        currentFunId = id
        for (param <- l)
          addVar(param.asIdent(), param.getType(), blockNr)
        block(b, 0)
        var returned : Boolean = returnTypeBlock(b, 0)
        removeBlock(0)
        if (!returned && currentFunType != TType("void"))
          exit("No return for function " + currentFunId)
      case _ =>
    }
  }

  def item(typ : Type, input : Item, blockNr : Int) = {
    input match {
      case INoInit(id) => addVar(id, typ, blockNr)
      case IInit(id, e) => 
        expType(e, blockNr, typ, typ)
        addVar(id, typ, blockNr)
      case INewInit(id, e) =>
        addVar(id, typ, blockNr)
    }
  }

  def initVar(id : LeftVar, blockNr : Int, e : Expr = EConst(1)) = {
  }

  def stmt(input : Stmt, blockNr : Int) : Unit = {
    input match {
      case SDecl(typ,itemList) =>
        for(i <- itemList)
          item(typ, i, blockNr)
      case SDecr(id) => goodType(id, blockNr, TType("int"))
      case SInc(id) => goodType(id, blockNr, TType("int"))
      case SExpr(e) => getType(e, blockNr)
      case SAss(LeftItem(l), e) => 
        // classType(l, blockNr)
      case SAss(id, e) => 
        var typ : Type = goodType(id, blockNr, TType("any"))
        if (!typ.isInstanceOf[TClass])
          expType(e, blockNr, typ, typ)
      case SVRet() => 
      case SRet(e) => 
      case SCond(e,s) => 
        getType(e, blockNr + 1)
        stmt(s, blockNr)
      case SCondElse(e,s1, s2) => 
        getType(e, blockNr)
        stmt(s1, blockNr + 1)
        stmt(s2, blockNr + 1)
      case SWhile(e, s) =>
        getType(e, blockNr)
        stmt(s, blockNr + 1)
      case SBlock(x) => 
        block(SBlock(x), blockNr + 1)
        removeBlock(blockNr + 1)
      case _ =>
        //TODO SFor
    }
  }

  def appArgs(id : String, blockNr: Int, params : List[Expr]) : Type = {
    func.get(id).get match {
      case (typ, typList) => 
        if (typList.length != params.length) exit("function " + id + " invalid number of arguments")
        for ((p, t) <- params.zip(typList)) {
          var typ: Type = getType(p, blockNr)
          if (typ != t.getType() && typ != TType("any")) exit("function " + id + " invalid argument type")
        }
        return typ
    }
  }

  def getType(input : Expr, blockNr : Int) : Type = {
    // println(input)
    var typ : Type = TType("any")
    input match {
      case LeftItem(l) => TType("any")
      case ELitTrue() => TType("boolean")
      case ELitFalse() => TType("boolean")
      case Ident(s) => { goodType(Ident(s), blockNr, TType("any")) }
      case Table(s, e) => { TType("int")}
      //case Struct(s, field) => { TType(s) }
      case RTable(_, e) => { TType("Rarray") }
      case RStruct(s) => { TType(s) }
      case EConst(v) => TType("int")
      case EString(s) => TType("string")
      case EApp(i, l) => appArgs(i, blockNr, l)
      case EAdd(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
      case ESub(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ)
      case EMul(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ)
      case EDiv(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ)
      case EMod(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ)
      case EUMinus(e1) => 
        expType(e1, blockNr)
      case EUNeg(e1) => 
        expType(e1, blockNr, TType("boolean"), TType("boolean"))
      case EGt(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
        //ifeq label
      case ELt(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
      case EGeq(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
      case ELeq(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
      case EEq(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
      case ENeq(e1, e2) =>
        typ = getType(e1, blockNr)
        expType(e2, blockNr, typ, typ)
        return TType("boolean")
      case EAnd(e1, e2) =>
        expTypeList(e1, blockNr, List(TType("int"), TType("boolean")))
        expTypeList(e2, blockNr, List(TType("int"), TType("boolean")))
        return TType("boolean")
      case EOr(e1, e2) => 
        expTypeList(e1, blockNr, List(TType("int"), TType("boolean")))
        expTypeList(e2, blockNr, List(TType("int"), TType("boolean")))
        return TType("boolean")
      case ECast(t) => return TClass(t)
      //TODO? EClassApp
      case _ => return TType("any")
    }
  }

  def finish() = {
    assCode = assCode.replaceFirst("strplace"+stringCount+"\n","")
    assCode += "_start:\ncall _main\nmovl $1,%eax\nint  $0x80\n"
  }

  def printToFile(f: java.io.File)(op: java.io.PrintWriter => Unit) {
    val p = new java.io.PrintWriter(f)
    try { op(p) } finally { p.close() }
  }

  def removeComments(code : String) : String = {
    return code.replaceAll("//.*\n", "\n").replaceAll("#.*\n", "\n").replaceAll("/\\*[\n|\\w\\W]*?\\*/", "\n")
  }

  def check(tokens : PParser.ProgramParser.ParseResult[List[Prog]] ) : Unit = {
    init()
    program(tokens)
  }
}
