#include <boost/spirit/include/qi.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include "jvm.h"

using namespace std;

template <typename Iterator>
std::string parse_numbers(Iterator first, Iterator last) {
    namespace qi = boost::spirit::qi;
    qi::rule<Iterator> id;
    qi::rule<Iterator, qi::space_type> group, expr1, expr2, expr3, expr, stmt, program;
    group = '(' >> expr >> ')';
    expr1 = qi::int_[&integer] | group | (+(qi::alpha))[&ident];
    expr2 = expr1 >> *(('*' >> expr1[&multiply]) | ('/' >> expr1[&divide]));
    expr3 = expr2 >> *('-' >> expr2[&sub]);
    expr = expr3 >> *('+' >> expr3[&add]);
    id = (+(qi::alpha))[&ident_assignemt];
    stmt = ((id >> qi::char_('=') >> expr[&flush_assignment])) | expr[&print];
    program = stmt >> *(';' >> stmt);
    bool r = qi::phrase_parse (first, last, program, qi::space);
    std::string body;
    for (auto it = v.begin(); it != v.end(); ++it) {
        body += *it + "\n  ";
    }
    if (!r || first != last)
        return "";
    return body;
}

int main(int args, char* argv[]) {
    ifstream myfile, out_template;
    std::string filename(argv[1]), dirname(".");
    int index = filename.rfind("/");
    if (index != -1) {
        dirname = filename.substr(0, index);
        filename = filename.substr(index+1);
    }
    filename = filename.substr(0, filename.rfind("."));
    myfile.open(argv[1]);
    out_template.open("src/jvm_template");
    stringstream buffer;
    buffer << myfile.rdbuf();
    string s = buffer.str();
    buffer.str("");
    buffer << out_template.rdbuf();
    string s2 = buffer.str();
    std::string body = parse_numbers(s.begin(), s.end());
    if (body != "") {
        boost::replace_all(s2, "CLASS_NAME", filename);
        boost::replace_all(s2, "BODY", body);
        boost::replace_all(s2, "STACK_SIZE", std::to_string(stack_size));
        boost::replace_all(s2, "LOCALS_SIZE", std::to_string(m.size()));
        ofstream outfile;
        std::string jasmin_file = dirname + '/' + filename + ".j";
        outfile.open(jasmin_file);
        outfile << s2;
        outfile.flush();
        std::string jasmin_command = "java -jar lib/jasmin.jar -d " + dirname + " " + jasmin_file;
        system(jasmin_command.c_str());
    }
    return 0;
}
