SQL:

I tried to solve third SQL task, but it would consume too much time.


Python:

To run:

```pip install -r requirements.txt
python -m flask run ```


Function modifies input data. There is basic script that sends request to flask app.

```pip install -r tests/requirements.txt
python example_request.py ```
